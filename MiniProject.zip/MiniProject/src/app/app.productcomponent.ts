import { Component } from '@angular/core';
import { Product } from './product';
import { ProductService } from './app.productservice'

@Component({
    selector: 'product-app',
    templateUrl: './app.product.html',
    styleUrls: ['./app.product.css'],
    providers: [ProductService]
})

export class ProductComponent {
    temp:number=0
    p: number = 1;
    model: any = {};
    up: any = {};
    Products: Product[];
    constructor(private getAllProducts: ProductService) { }   //DI
    ngOnInit(): any {
        this.getAllProducts.getAllProducts().subscribe((data: Product[]) => this.Products = data);
    }

    addDetails(): any {
        this.temp=5
        if(this.model.id=="" || this.model.Name=="" || this.model.Price=="" || this.model.Description==""  )
        {
            this.temp=1
        }
        this.Products.map((x)=>{
            if(x.id==this.model.id){
                this.temp++
                alert("You cannot Add the existing Id")
            }
        })
       if(this.temp==5)
           {
                this.Products.push(this.model)
            
        }
        this.model = {};
        }

       
    

    update(eid: number): any {
       
        for (let i in this.Products) {
            if (this.Products[i].id == eid) {
                this.up = this.Products[i];
            
        }

        }
    }

    updatenew(): any {
        if(this.up.id=="" || this.up.Name=="" || this.up.Price=="" || this.up.Description==""  )
        {
            this.temp=1
        }
        this.Products.map((x)=>{
            // if(x.id==this.up.id){
            //     alert("You cannot Edit the existing Id")
            // }
        })
        this.up.id = (document.getElementById("prid") as HTMLInputElement).value;
        this.up.Name = (document.getElementById("prname") as HTMLInputElement).value;
        this.up.Description = (document.getElementById("prdesc") as HTMLInputElement).value;
        this.up.Price = (document.getElementById("prprice") as HTMLInputElement).value;

        this.up = {}
    }

    delete(eid: number): any {
        if (confirm("Are you sure you want to delete data?")) {
            for (let i in this.Products) {

                if (this.Products[i].id == eid) {
                    this.Products.splice(Number(i), 1);
                }

            }
        }
    }

    deleteAll(): any {

        if (confirm("Are you sure you want to delete whole data?")) {
        this.Products.splice(0, this.Products.length);
    }
    }

}

